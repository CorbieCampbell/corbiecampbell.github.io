let darkmode = localStorage.getItem('darkmode');
const themeSwitch = document.getElementById('theme-switch');

// Activates darkmode theme (in CSS) if the theme is currently in brightmode and the button is clicked
const enableDarkmode = () => {
  document.body.classList.add('darkmode');
  localStorage.setItem('darkmode', 'active');
}

// Reverts back to brightmode (root in CSS) if currently in darkmode and button is clicked
const disableDarkmode = () => {
  document.body.classList.remove('darkmode');
  localStorage.setItem('darkmode', null);
}

if(darkmode === "active") enableDarkmode()

// Once light/darkmode button is clicked, check what the current theme is and then swap it appropriately
themeSwitch.addEventListener("click", () => {
  darkmode = localStorage.getItem('darkmode');
  darkmode !== "active" ? enableDarkmode() : disableDarkmode();
})
// Code to help pull data from a single JSON file, not used in tandem with MongoDB
// var fs = require('fs');
// var terms = JSON.parse(fs.readFileSync('./data/terms.json', 'utf8'));

// Code to help pull data from the MongoDB and display on the webpage
const termsEndpoint = 'http://localhost:3000/api/glossary';
const options = {
    method: "GET",
    headers: {
        Accept: 'application/json'
    },
};

/* GET homepage */
const index = async function (req, res, next) {
    await fetch(termsEndpoint, options)
        .then((res) => res.json())
        .then((json) => {
            let message = null;
            if (!(json instanceof Array)) {
                message = "API lookup error";
                json = [];
            }
            else {
                if (!json.length) {
                    message = "No glossary items in database";
                }
            }
            res.render("index", { title: "Online Glossary", terms: json, message });
        })
        .catch((err) => res.status(500).send(err.message));
};

module.exports = {
    index
};
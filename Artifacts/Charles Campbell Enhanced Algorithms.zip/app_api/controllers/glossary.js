const mongoose = require('mongoose');
// Register model
const Term = require('../models/terms');
const Model = mongoose.model('terms');

// Get -> /terms - this lists all the items in the database
// Regardless of the outcome, response must include HTML status code
// & JSON message to the requesting client
const termsList = async(req, res) => {
    const q = await Model
        // No filter, return all records     
        .find({})
        .exec();

        // Following line helps show results of query on console/terminal
        // Uncomment to verify
        // console.log(q);

    if (!q) {
        // Database returns no data
        return res
            .status(404)
            .json(err);
    }
    else {
        // Return correct trip list
        return res
            .status(200)
            .json(q);
    }
};

// Get -> /terms/_id - this selects a single term from the database
// Regardless of the outcome, response must include HTML status code
// & JSON message to the requesting client
const termsFindByID = async(req, res) => {
    const q = await Model
        // Return a single record from the database     
        .find({ _id : req.params._id })
        .exec();

        // Following line helps show results of query on console/terminal
        // Uncomment to verify
        // console.log(q);

    if (!q) {
        // Database returns no data
        return res
            .status(404)
            .json(err);
    }
    else {
        // Return correct trip list
        return res
            .status(200)
            .json(q);
    }
};

// POST: /term - Adds a new term
// Regardless of the outcome, response must include HTML status code
// & JSON message to the requesting client
const termsAddTerm = async(req, res) => {
    const newTerm = new Term ({
        term: req.body.term,
        description: req.body.description
    });

    const q = await newTerm.save();

    // Following line helps show results of query on console/terminal
    // Uncomment to verify
    // console.log(q);
        
    if (!q) {
        // Database returns no data
        return res
            .status(400)
            .json(err);
    }
    else {
        // Return newly added trip
        return res
            .status(201)
            .json(q);
    }
}

// PUT: /terms/:term (name) - Updates a term
// Regardless of the outcome, response must include HTML status code
// & JSON message to the requesting client
const termsUpdateTerm = async (req, res) => {
    
    // Uncomment for debugging
    console.log(req.params);
    console.log(req.body);

    const q = await Model
        .findOneAndUpdate(
            // Parameter to find the trip to update
            { _id: req.params._id },
            // Data that will be input to trip
            {
                term: req.body.term,
                description: req.body.description
            },
            { new: true, runValidators: true}
        )
        .exec();

    if (!q) {
        // Database returns no data
        return res
            .status(400)
            .json(err);
    }
    else {
        // Return newly added trip
        return res
            .status(201)
            .json(q);
    }

    // Uncomment the following line to show results of operation on the console
    // console.log(q);
};

// DELETE: /glossary/:_id - Deletes a term from the glossary
const termsDeleteTerm = async (req, res) => {
    try {
        const result = await Model.findByIdAndDelete(req.params._id);
        
        if (!result) {
            return res.status(404).json({ message: 'Term not found' });
        }
    return res.status(204).json(); // No content
  }
  catch (err) {
    console.error('Delete error:', err);
    return res.status(500).json({ message: 'Delete failed', error: err });
  }
};


module.exports = {
    termsList,
    termsFindByID,
    termsAddTerm,
    termsUpdateTerm,
    termsDeleteTerm
};
var accordion = document.getElementsByClassName("accordion");
var i;

// Function to help display the contents of an item in the glossary when a user clicks on it
document.addEventListener('click', function (e) {
    if (e.target.classList.contains('accordion')) {
      e.target.classList.toggle('active');
      const panel = e.target.nextElementSibling;
      panel.style.display = (panel.style.display === "block") ? "none" : "block";
    }
  });

function searchFunction() {
  // Declare user search variables
  var input, filter;
  input = document.getElementById("searchInput");
  filter = input.value.toUpperCase();

  // Loop through all list items, and hide those who don't match the search query
  const accordions = document.getElementsByClassName("accordion");
  for (i = 0; i < accordions.length; i++) {
    // Get the glossary item title
    const title = accordions[i].textContent;
    // If the glossary item matches the users search
    if (title.toUpperCase().indexOf(filter) > -1) {
        // Only display that item in the accordion
        accordion[i].style.display = '';
    }
    // Otherwise, don't display anything
    else {
      accordion[i].style.display = 'none';
    }
  }
}

// Refresh function to help reload the webpage whenever a new item is added, edited/updated, or deleted
async function refreshGlossary() {
  const res = await fetch('/api/glossary');
  const data = await res.json();

  // Sorts the glossary alphabetically
  data.sort((a, b) => a.term.toLowerCase().localeCompare(b.term.toLowerCase()));

  const glossarySection = document.querySelector('section');
  glossarySection.innerHTML = '';

  glossarySection.innerHTML += `
    <input type="text" id="searchInput" onkeyup="searchFunction()" placeholder="Search:">
  `;

  // Rebuild glossary entries
  data.forEach(term => {
    const button = document.createElement('button');
    button.className = 'accordion';
    button.textContent = term.term;

    const panel = document.createElement('div');
    panel.className = 'panel';
    panel.innerHTML = `
      <p>${term.description}</p>
      <button class="editButton" data-id="${term._id}">Edit</button>
      <button class="deleteButton" data-id="${term._id}">Delete</button>
      <div class="editFormContainer" style="display:none;">
        <h2>Edit Term</h2>
        <form class="editTermForm">
          <input type="text" name="term" value="${term.term}" required><br><br>
          <textarea name="description" required>${term.description}</textarea><br><br>
          <button type="submit">Save Changes</button>
        </form>
      </div>`;

    glossarySection.appendChild(button);
    glossarySection.appendChild(panel);
  });

  // Append Add button and form after the loop
  glossarySection.innerHTML += `
    <p><br></p>
    <button id="addButton">Add</button>
    <div id="addForm" style="display:none;">
      <h2> Input Term Info </h2>
      <form id="addTermForm">
        <label for="addTerm">Term Name: </label>
        <input type="text" id="addTerm" name="term" required><br><br>
        <label for="addDescription">Description: </label>
        <textarea id="addDescription" name="description" required></textarea><br><br>
        <button type="submit">Save</button>
      </form>
    </div>
  `;
}
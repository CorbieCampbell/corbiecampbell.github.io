// Register model
const { getGlossaryModel } = require('../models/glossaryFactory')

// Get -> /terms - this lists all the items in the database
// Regardless of the outcome, response must include HTML status code
// & JSON message to the requesting client
const termsList = async (req, res) => {
  const glossaryName = req.query.collection || 'terms';
  const Term = getGlossaryModel(glossaryName);

  try {
    const results = await Term.find({}).exec();
    res.status(200).json(results);
  } catch (err) {
    res.status(404).json({ message: 'Collection not found', error: err });
  }
};

// Get -> /terms/_id - this selects a single term from the database
// Regardless of the outcome, response must include HTML status code
// & JSON message to the requesting client
const termsFindByID = async (req, res) => {
    const glossaryName = req.query.collection || 'terms';
    const Term = getGlossaryModel(glossaryName);

    try {
        const result = await Term.findById(req.params._id).exec();
        if (!result) {
            return res.status(404).json({ message: 'Term not found' });
        }
        res.status(200).json(result);
    } catch (err) {
        res.status(400).json({ message: 'Invalid ID format', error: err });
    }
};

// POST: /term - Adds a new term
// Regardless of the outcome, response must include HTML status code
// & JSON message to the requesting client
const termsAddTerm = async (req, res) => {
    const glossaryName = req.query.collection || 'terms';
    const Term = getGlossaryModel(glossaryName);

    const newTerm = new Term({
        term: req.body.term,
        description: req.body.description
    });

    try {
        const result = await newTerm.save();
        res.status(201).json(result);
    } catch (err) {
        res.status(400).json({ message: 'Failed to add term', error: err });
    }
};


// PUT: /terms/:term (_id) - Updates a term
// Regardless of the outcome, response must include HTML status code
// & JSON message to the requesting client
const termsUpdateTerm = async (req, res) => {
    const glossaryName = req.query.collection || 'terms';
    const Term = getGlossaryModel(glossaryName);

    try {
        const result = await Term.findByIdAndUpdate(
            req.params._id,
            {
                term: req.body.term,
                description: req.body.description
            },
            { new: true, runValidators: true }
        ).exec();

        if (!result) {
            return res.status(404).json({ message: 'Term not found for update' });
        }

        res.status(200).json(result);
    } catch (err) {
        res.status(400).json({ message: 'Update failed', error: err });
    }
};

// DELETE: /glossary/:_id - Deletes a term from the glossary
const termsDeleteTerm = async (req, res) => {
    const glossaryName = req.query.collection || 'terms';
    const Term = getGlossaryModel(glossaryName);

    try {
        const result = await Term.findByIdAndDelete(req.params._id).exec();

        if (!result) {
            return res.status(404).json({ message: 'Term not found for deletion' });
        }

        res.status(204).json();
    } catch (err) {
        res.status(500).json({ message: 'Delete failed', error: err });
    }
};

module.exports = {
    termsList,
    termsFindByID,
    termsAddTerm,
    termsUpdateTerm,
    termsDeleteTerm
};
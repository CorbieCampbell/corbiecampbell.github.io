// Express application
const express = require("express");
// Router logic
const router = express.Router();

// Import the controllers needed to route
const termsController = require('../controllers/glossary');

const glossaryAdminController = require('../controllers/glossaryAdmin');

router
    .route('/glossaries')
    .get(glossaryAdminController.listCollections)
    .post(glossaryAdminController.createCollection);

router
    .route('/glossaries/:name')
    .delete(glossaryAdminController.deleteCollection);

// Define methods that route for trips endpoint :
router
    .route('/glossary')
    // GET method that routes the entire termsList
    .get(termsController.termsList)
    // POST method that helps add a new term to the database
    .post(termsController.termsAddTerm);

router
    .route('/glossary/:_id')
    // GET method that routes termsFindByID - requires parameter
    .get(termsController.termsFindByID)
    // PUT method that routes termsUpdateTerm - requires parameter
    .put(termsController.termsUpdateTerm)
    // DELETE method that routes termsDeleteTerm - requires parameter
    .delete(termsController.termsDeleteTerm);

module.exports = router;
var accordion = document.getElementsByClassName("accordion");
var i;

// For loop to help display the contents of an item in the glossary when a user clicks on it
for (i = 0; i < accordion.length; i++) {
  accordion[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    }
    else {
      panel.style.display = "block";
    }
  });
}

function searchFunction() {
  // Declare user search variables
  var input, filter;
  input = document.getElementById("searchInput");
  filter = input.value.toUpperCase();

  // Loop through all list items, and hide those who don't match the search query
  for (i = 0; i < accordion.length; i++) {
    // Get the glossary item title
    const title = accordion[i].textContent;
    // If the glossary item matches the users search
    if (title.toUpperCase().indexOf(filter) > -1) {
        // Only display that item in the accordion
        accordion[i].style.display = '';
    }
    // Otherwise, don't display anything
    else {
      accordion[i].style.display = 'none';
    }
  }
}
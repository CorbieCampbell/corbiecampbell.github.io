// DELETE FUNCTIONALITY
async function deleteTerm(_id) {
  try {
    const response = await fetch(`/api/glossary/${_id}`, {
      method: "DELETE"
    });

    if (response.status === 204) {
      console.log("Successfully deleted term");
      refreshGlossary(); // Update UI
    } else {
      const err = await response.json();
      console.error("Delete failed", err.message || "Unknown error");
    }
  } catch (err) {
    console.error("Delete request failed", err);
  }
}

document.addEventListener('click', async function (event) {
  const target = event.target;

  // Toggle Add form
  if (target.id === 'addButton') {
    const addForm = document.getElementById('addForm');
    addForm.style.display = (addForm.style.display === 'block') ? 'none' : 'block';
  }

  // Toggle Edit form
  if (target.classList.contains('editButton')) {
    const panel = target.closest('.panel');
    const editForm = panel.querySelector('.editFormContainer');
    const textarea = editForm.querySelector('textarea');

    // Toggles visibility
    editForm.style.display = (editForm.style.display === 'block') ? 'none' : 'block';

    // Auto-resize textarea to fit content
    textarea.style.height = 'auto';
    textarea.style.height = textarea.scrollHeight + 'px';
  }

  // Handle Delete
  if (target.classList.contains('deleteButton')) {
    const termId = target.getAttribute('data-id');
    deleteTerm(termId);
  }
});

document.addEventListener('submit', async function (event) {
  const form = event.target;

  // ADD FORM
  if (form.id === 'addTermForm') {
    event.preventDefault();

    const term = form.term.value;
    const description = form.description.value;

    const response = await fetch('/api/glossary', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ term, description })
    });

    if (response.ok) {
      refreshGlossary();
    } else {
      const errText = await response.text();
      console.error('Failed to add item:', errText);
      alert('Failed to add item.');
    }
  }

  // EDIT FORM
  if (form.classList.contains('editTermForm')) {
    event.preventDefault();

    const container = form.closest('.panel');
    const _id = container.querySelector('.editButton').getAttribute('data-id');
    const term = form.term.value;
    const description = form.description.value;

    const response = await fetch(`/api/glossary/${_id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ term, description })
    });

    if (response.ok) {
      refreshGlossary();
    } else {
      const errText = await response.text();
      console.error('Failed to edit item:', errText);
      alert('Failed to edit item.');
    }
  }
});
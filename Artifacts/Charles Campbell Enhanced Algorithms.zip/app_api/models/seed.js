// Bring in the DB connection and the Terms Schema
const Mongoose = require('./db');
const Term = require('./terms');

// Read seed data from json file
var fs = require('fs');
var terms = JSON.parse(fs.readFileSync('./data/terms.json', 'utf8'));

// delete existing records, insert seed data (can be edited in: data/terms.json)
const seedDB = async () => {
    await Term.deleteMany({});
    await Term.insertMany(terms);
}

// Close MongoDB connection & exit
seedDB().then(async () => {
    await Mongoose.connection.close();
    process.exit(0);
});
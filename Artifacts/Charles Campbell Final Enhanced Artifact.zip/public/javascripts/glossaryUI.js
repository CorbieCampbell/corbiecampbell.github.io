import {
  getGlossaryList,
  getGlossaryTerms,
  addGlossary,
  addTerm,
  updateTerm,
  deleteTerm,
  deleteGlossary
} from './CRUD.js';

let currentGlossary = 'terms';
let glossaryTerms = [];

// 🛠 Modular binding helper
function bindIfNeeded(selector, handler) {
  document.querySelectorAll(selector).forEach(el => {
    if (el.dataset.bound === 'true') return;
    el.dataset.bound = 'true';
    handler(el);
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  await loadGlossaryList();
  await refreshGlossaryUI();
  setupGlossaryControls();
  setupGlossaryDeleteModal();
  setupAddTermForm();
  setupDeleteModal();

  document.addEventListener('input', e => {
    if (e.target.id === 'searchInput') {
      const query = e.target.value.trim().toLowerCase();
      const filtered = glossaryTerms.filter(({ term }) => term.toLowerCase().includes(query))
                                    .sort((a, b) => a.term.toLowerCase().localeCompare(b.term.toLowerCase()));
      renderGlossary(filtered);
    }
  });

  document.addEventListener('click', e => {
    if (e.target.id === 'addButton') {
      const formDiv = document.getElementById('addForm');
      if (formDiv) {
        formDiv.style.display =
          formDiv.style.display === 'none' ? 'block' : 'none';
      }
    }
  });

  document.addEventListener('submit', async e => {
  const form = e.target;
  if (form.id === 'addTermForm') {
    e.preventDefault();

    const term = form.term.value.trim();
    const description = form.description.value.trim();
    if (!term || !description) {
      alert('Please fill out both fields');
      return;
    }

    const res = await addTerm(term, description, currentGlossary);
      if (res) {
        form.reset();
        document.getElementById('addForm').style.display = 'none';
        await refreshGlossaryUI();
      }
    }
  });

});

async function loadGlossaryList() {
  const names = await getGlossaryList();
  names.sort((a, b) => a === 'terms' ? -1 : b === 'terms' ? 1 : a.localeCompare(b));

  const container = document.getElementById('glossarySelector');
  container.innerHTML = '';

  names.forEach(name => {
    const wrapper = document.createElement('div');
    wrapper.className = name === 'terms' ? 'glossaryItemWrapper glossaryTermsGroup' : 'glossaryItemWrapper';

    const btn = document.createElement('button');
    btn.textContent = name;
    btn.className = (name === currentGlossary) ? 'activeGlossary' : '';
    btn.addEventListener('click', async () => {
      currentGlossary = name;
      await refreshGlossaryUI();
      await loadGlossaryList();
    });

    wrapper.appendChild(btn);

    if (name !== 'terms') {
      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = '🗑';
      deleteBtn.className = 'deleteGlossaryBtn';
      deleteBtn.dataset.glossary = name;
      deleteBtn.addEventListener('click', () => {
        window.showGlossaryDeleteModal(name);
      });

      wrapper.appendChild(deleteBtn);
    }

    container.appendChild(wrapper);
  });
}

function setupGlossaryControls() {
  let creatingGlossary = false;
  
  document.getElementById('createGlossaryBtn').addEventListener('click', async () => {
    if (creatingGlossary) return;
    creatingGlossary = true;

    const nameInput = document.getElementById('newGlossaryName');
    const name = nameInput.value.trim().toLowerCase();

    if (!name) {
      alert('Please enter a name');
      creatingGlossary = false;
      return;
    }

    const res = await addGlossary(name);
    creatingGlossary = false;

    if (res) {
      currentGlossary = name;
      await loadGlossaryList();
      await refreshGlossaryUI();
      nameInput.value = '';
      document.getElementById('newGlossaryForm').style.display = 'none';
    } else {
      alert('Failed to create glossary');
    }
  });
}

function setupGlossaryDeleteModal() {
  const modal = document.getElementById('deleteModal');
  const message = document.getElementById('deleteModalMessage');
  const confirmBtn = document.getElementById('confirmDeleteBtn');
  const cancelBtn = document.getElementById('cancelDeleteBtn');

  let glossaryToDelete = null;

  window.showGlossaryDeleteModal = function (glossaryName) {
    glossaryToDelete = glossaryName;
    message.textContent = `Delete glossary "${glossaryName}" and all its terms?`;
    modal.style.display = 'flex';
  };

  confirmBtn.onclick = async () => {
    if (!glossaryToDelete || glossaryToDelete === 'terms') return;

    const res = await deleteGlossary(glossaryToDelete);
    if (res) {
      glossaryToDelete = null;
      modal.style.display = 'none';
      currentGlossary = 'terms';
      await loadGlossaryList();
      await refreshGlossaryUI();
    }
  };

  cancelBtn.onclick = () => {
    glossaryToDelete = null;
    modal.style.display = 'none';
  };
}

async function refreshGlossaryUI() {
  const container = document.querySelector('section');
  container.innerHTML = `
    <input type="text" id="searchInput" placeholder="Search:">
    <div id="accordionContainer"></div>
    <p><br></p>
    <button id="addButton">Add</button>
    <div id="addForm" style="display:none;">
      <h2> Input Term Info </h2>
      <form id="addTermForm">
        <label for="addTerm">Term Name: </label>
        <input type="text" id="addTerm" name="term" required><br><br>
        <label for="addDescription">Description: </label>
        <textarea id="addDescription" name="description" required></textarea><br><br>
        <button type="submit">Save</button>
      </form>
    </div>
  `;

  glossaryTerms = await getGlossaryTerms(currentGlossary);
  glossaryTerms.sort((a,b) => a.term.toLowerCase().localeCompare(b.term.toLowerCase()));
  renderGlossary(glossaryTerms);
}

function renderGlossary(terms) {
  const accordion = document.getElementById('accordionContainer');
  accordion.innerHTML = '';

  terms.forEach(({ term, description, _id }) => {
    const panel = document.createElement('div');
    panel.innerHTML = `
      <button class="accordion">${term}</button>
      <div class="panel" style="display: none;">
        <p>${description}</p>
        <button class="editButton" data-id="${_id}">Edit</button>
        <button class="deleteButton" data-id="${_id}">Delete</button>
        <div class="editFormContainer" style="display:none;">
          <h2>Edit Term</h2>
          <form class="editTermForm">
            <input type="text" name="term" value="${term}" required><br><br>
            <textarea name="description" required>${description}</textarea><br><br>
            <button type="submit">Save Changes</button>
          </form>
        </div>
      </div>
    `;
    accordion.appendChild(panel);
  });

  setupAccordionInteractions();
  setupEditActions();
  setupDeleteActions();
}

function setupAccordionInteractions() {
  bindIfNeeded('.accordion', button => {
    button.addEventListener('click', () => {
      const panel = button.nextElementSibling;
      if (!panel || !panel.classList.contains('panel')) return;

      const isExpanded = button.classList.contains('active');
      console.log('Clicked:', button.textContent, '| Expanding:', !isExpanded);

      button.classList.toggle('active');
      panel.style.display = isExpanded ? 'none' : 'block';
    });
  });
}

function setupAddTermForm() {
  const form = document.getElementById('addTermForm');
  if (!form || form.dataset.bound === 'true') return;

  form.dataset.bound = 'true';
  
  const toggleBtn = document.getElementById('addButton');
}

function setupEditActions() {
  bindIfNeeded('.editButton', button => {
    const container = button.closest('.panel');
    const formContainer = container.querySelector('.editFormContainer');
    const form = formContainer.querySelector('.editTermForm');

    button.addEventListener('click', () => {
      formContainer.style.display =
        formContainer.style.display === 'none' ? 'block' : 'none';
    });

    form.addEventListener('submit', async e => {
      e.preventDefault();
      const _id = button.dataset.id;
      const term = form.term.value;
      const description = form.description.value;

      const res = await updateTerm(_id, term, description, currentGlossary);
      if (res) await refreshGlossaryUI();
    });
  });
}

function setupDeleteActions() {
  bindIfNeeded('.deleteButton', button => {
    button.addEventListener('click', () => {
      const _id = button.dataset.id;
      const termButton = button.closest('.panel')?.previousElementSibling;
      const termName = termButton?.textContent.trim() || 'this term';
      window.showDeleteModal(_id, termName);
    });
  });
}


function setupDeleteModal() {
  const modal = document.getElementById('deleteModal');
  const message = document.getElementById('deleteModalMessage');
  const confirmBtn = document.getElementById('confirmDeleteBtn');
  const cancelBtn = document.getElementById('cancelDeleteBtn');

  let pendingId = null;
  let pendingTerm = '';

  window.showDeleteModal = function (termId, termName) {
    pendingId = termId;
    pendingTerm = termName;
    message.textContent = `Are you sure you want to delete "${termName}"?`;
    modal.style.display = 'flex';
  };

  confirmBtn.addEventListener('click', async () => {
    if (!pendingId) return;

    const success = await deleteTerm(pendingId, currentGlossary);
    if (success) await refreshGlossaryUI();

    modal.style.display = 'none';
    pendingId = null;
    pendingTerm = '';
  });

  cancelBtn.addEventListener('click', () => {
    modal.style.display = 'none';
    pendingId = null;
    pendingTerm = '';
  });
}
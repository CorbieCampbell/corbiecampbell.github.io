const mongoose = require('mongoose');

function getGlossaryModel(name) {
  const schema = new mongoose.Schema({
    term: String,
    description: String
  });

  return mongoose.models[name] || mongoose.model(name, schema);
}

module.exports = {
    getGlossaryModel
};
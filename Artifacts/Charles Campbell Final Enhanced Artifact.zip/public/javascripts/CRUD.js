let currentGlossary = 'terms'; // default glossary

// public/javascripts/CRUD.js
export async function getGlossaryList() {
  try {
    const res = await fetch('/api/glossaries');
    if (!res.ok) throw new Error(`Failed to fetch glossary list: ${res.status}`);
    return await res.json();
  } catch (err) {
    console.error(err);
    return []; // fallback to empty array
  }
}

export async function getGlossaryTerms(collection) {
  try {
    const res = await fetch(`/api/glossary?collection=${collection}`);
    if (!res.ok) throw new Error(`Failed to fetch terms for "${collection}": ${res.status}`);
    return await res.json();
  } catch (err) {
    console.error(err);
    return [];
  }
}

export async function addGlossary(name) {
  try {
    const res = await fetch('/api/glossaries', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name })
    });
    if (!res.ok) throw new Error(`Failed to add glossary "${name}": ${res.status}`);
    return await res.json();
  } catch (err) {
    console.error(err);
    return null;
  }
}

export async function deleteGlossary(name) {
  try {
    const res = await fetch(`/api/glossaries/${name}`, {
      method: 'DELETE'
    });

    const result = await res.json();
    if (res.ok) {
      console.log(`Deleted glossary: ${name}`);
      return true;
    } else {
      console.warn(result.message || 'Failed to delete glossary');
      return false;
    }
  } catch (err) {
    console.error('Error deleting glossary:', err);
    return false;
  }
}

export async function addTerm(term, description, collection) {
  try {
    const res = await fetch(`/api/glossary?collection=${collection}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ term, description })
    });
    if (!res.ok) throw new Error(`Failed to add term "${term}": ${res.status}`);
    return await res.json();
  } catch (err) {
    console.error(err);
    return null;
  }
}

export async function updateTerm(_id, term, description, collection) {
  try {
    const res = await fetch(`/api/glossary/${_id}?collection=${collection}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ term, description })
    });
    if (!res.ok) throw new Error(`Failed to update term "${term}": ${res.status}`);
    return await res.json();
  } catch (err) {
    console.error(err);
    return null;
  }
}

export async function deleteTerm(_id, collection) {
  try {
    const res = await fetch(`/api/glossary/${_id}?collection=${collection}`, {
      method: 'DELETE'
    });
    if (!res.ok) throw new Error(`Failed to delete term ID ${_id}: ${res.status}`);
    return true;
  } catch (err) {
    console.error(err);
    return null;
  }
}
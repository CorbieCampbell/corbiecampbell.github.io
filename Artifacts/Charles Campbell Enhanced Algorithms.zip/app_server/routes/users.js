// This is what a users router would be, but it is not utilized in this SPA
// Should you need it for your webpage, simply remove the comments (//) on the coode

// var express = require('express');
// var router = express.Router();

/* GET users listing. */
// router.get('/', function(req, res, next) {
//  res.send('respond with a resource');
// });

// module.exports = router;
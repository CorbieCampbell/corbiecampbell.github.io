const mongoose = require('mongoose');

// Define the terms schema
const termSchema = new mongoose.Schema({
    term: { type: String, required: true, index: true },
    description: { type: String, required: true }
});

const Term = mongoose.model('terms', termSchema);
module.exports = Term;
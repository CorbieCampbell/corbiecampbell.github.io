const mongoose = require('mongoose');

// List all glossary collections
const listCollections = async (req, res) => {
  try {
    const collections = await mongoose.connection.db.listCollections().toArray();
    const glossaryNames = collections.map(col => col.name);
    res.status(200).json(glossaryNames);
  } catch (err) {
    res.status(500).json({ message: 'Failed to list glossaries', error: err });
  }
};

// Create a new glossary collection
const createCollection = async (req, res) => {
  const name = req.body.name;

  if (!name || typeof name !== 'string') {
    return res.status(400).json({ message: 'Glossary name is required and must be a string' });
  }

  try {
    const existing = await mongoose.connection.db.listCollections({ name }).toArray();
    if (existing.length > 0) {
      return res.status(409).json({ message: 'Glossary already exists' });
    }

    await mongoose.connection.createCollection(name);
    res.status(201).json({ message: 'Glossary created', name });
  } catch (err) {
    res.status(500).json({ message: 'Failed to create glossary', error: err });
  }
};

// Delete a glossary collection
const deleteCollection = async (req, res) => {
  const name = req.params.name;

  if (name === 'terms') {
    return res.status(403).json({ message: 'Cannot delete the default glossary' });
  }

  try {
    const existing = await mongoose.connection.db.listCollections({ name }).toArray();

    if (existing.length === 0) {
      return res.status(404).json({ message: 'Glossary does not exist' });
    }

    await mongoose.connection.db.dropCollection(name);
    res.status(200).json({ message: `Glossary "${name}" deleted successfully` });
  } catch (err) {
    console.error(`Error dropping collection "${name}":`, err);
    res.status(500).json({ message: 'Failed to delete glossary', error: err });
  }
};

module.exports = {
    listCollections,
    createCollection,
    deleteCollection
};
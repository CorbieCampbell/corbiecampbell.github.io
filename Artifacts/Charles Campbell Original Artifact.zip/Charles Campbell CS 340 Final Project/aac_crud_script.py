# Script Developed By: Charles Campbell
# Date: April 11, 2025

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter:
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password, host, port, database, collection):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = username
        PASS = password
        HOST = host
        PORT = port
        DB = database
        COL = collection
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Create method to implement the C (Create) in CRUD.
    def create(self, data):
        if data is not None:
            insertData = self.database.animals.insert_one(data)  # data should be dictionary
            # If data is inserted into the database, return true
            if insertData is not None:
                return True
            # Otherwise, return false
            else:
                return False
        else:
            raise Exception("Nothing to create, because data parameter is empty")

# APRIL 11 EDIT: Empty (None) query will now return a full list of all the documents in the database
# Create method to implement the R (Read) in CRUD.
    def read(self, query):
        if query is not None:
            results = list(self.database.animals.find(query)) # data should be dictionary
        elif query is None:
            results = list(self.database.animals.find())
        else:
            raise Exception("Nothing to create, because data parameter is empty")
        return results
        
# Create method to implement the U (Update) in CRUD.
    def update(self, searchData, updateData):
        if searchData is not None:
            results = self.database.animals.update_many(searchData, { "$set": updateData}) # data should be dictionary
        else:
            raise Exception("Nothing to update, because data parameter is empty")
        return results.raw_result
        
# Create method to implement the D (Delete) in CRUD.
    def delete(self, deleteData):
        if deleteData is not None:
            results = self.database.animals.delete_many(deleteData) # data should be dictionary
        else:
            raise Exception("Nothing to delete, because data parameter is empty")
        return results.raw_result
